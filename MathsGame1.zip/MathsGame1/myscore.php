<?php
 session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
</head>
<style>
body{
  background-image: url('bg7.jpg');
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
<body>
  <?php include("indexnav.php"); ?><br>
  <div class="container-fluid">
    <div>
      <center><h1>Test Result</h1></center>
    </div>
    <div class="row mt-5">
      <div class="col-lg-6 ">
        <div>
          <center><h3>Doughnut Chart</h3></center>
          <center><canvas id="doughnutChart" style="max-width: 300px;"></canvas></center>
        </div>
      </div>
      <div class="col-lg-6">
        <center>
          <h3>Result</h3>
          <table class="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Result</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-">Unanswer:</td>
                <td><?php echo $unanswered;?></td>
              </tr>
              <tr>
                <td>Correct Answer:</td>
                <td><?php echo $right_answer;?></td>
              </tr>
              <tr>
                <td>Wrong Answer:</td>
                <td><?php echo $wrong_answer;?></td>
              </tr>
            </tbody>
          </table>
          <a href="score.php" class="btn btn-outline-warning" role="button">Try Again</a>
        </center>
      </div>
      </div>
    </div>

    <?php
    $servername ="localhost";
    $username = "rahul";
    $password = "Rahul@123";
    $dbname = "quiz2";

    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if (!$conn) {
      die("Connection failed:". mysqli_connect_error());
    }

    $unanswer = '';
    $correct_ans = '';
    $wrong_ans = '';
    $email = $_SESSION['email'];
    //var_dump($_SESSION['User']);
    $sql = "SELECT *
      FROM myscore
      WHERE email = '$email'";
      //echo "$sql";
    $res = mysqli_query($conn,$sql);

    while ($row = mysqli_fetch_array($res)){
      $unanswer = $unanswer.'"'. $row['unanswer'].'",';
      $correct_ans= $correct_ans.'"'. $row['correct_ans'].'",';
      $wrong_ans= $wrong_ans.'"'. $row['wrong_ans'].'",';
    }

    $unanswer = trim($unanswer,",");
    $correct_ans = trim($correct_ans,",");
    $wrong_ans = trim($wrong_ans,",");
    ?>

    <script>
    var mypie= document.getElementById("doughnutChart").getContext('2d');
    var myPieChart = new Chart(mypie,{
      type: 'doughnut',
      data: {
        labels: ["Unanswer", "Correct Answer", "Wrong Answer"],
        datasets:
        [{
          data: [<?php echo $unanswer;?>,<?php echo $correct_ans;?>,<?php echo $wrong_ans;?>],
          backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C"],
          hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870"]
        }]
      },
      options: {
        responsive: true
      }
    });
  </script>
  </div>
</body>
</html>
