<?php

$conn=mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");
if(isset($_POST['add'])){
  $name=$_POST['grade'];
  $des=$_POST['agelimit'];
  $sql="insert into grade values(null,'".$name."','".$des."')";
  echo $sql;
  $result=mysqli_query($conn,$sql);
  if($result){
  header('Location:agegroup.php?msg=Age Group Add Succesfully..');
  }
  else{
    header('Location:agegroup.php?msg=Age group not added');
  }
}
else{
  echo"Error";
}










 ?>
