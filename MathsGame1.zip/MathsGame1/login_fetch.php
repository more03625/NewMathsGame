
<?php
      session_start();
      //$con=mysqli_connect("localhost","root","","quiz");
      $servername ="localhost";
      $username = "rahul";
      $password = "Rahul@123";
      $dbname = "quiz2";

      $con = mysqli_connect($servername,$username,$password,$dbname);
      if ($con) {
        if (isset($_POST['submit'])) {
          $email=$_POST['email'];
          $pass=$_POST['pswd'];
          $sql="select * from signup where email_id='$email'";
          $result=mysqli_query($con,$sql);
          $row=mysqli_fetch_assoc($result);

          if ($row) {
            if ($row['email_id']===$email && $row['password']===$pass) {
              $_SESSION['id']=$row['User_id'];
                $_SESSION['User']=$row['Name'];
              header('Location:Homepage.php');
            }
            else{
              $msg="username or password incorrect...";
              echo"<script type='text/javascript'>alert('$msg');window.location= 'login.php';</script>";
            }
          }
          else{
            if($row1){
            if ($row1['email_id']===$email && $row1['password']===$pass) {
           $_SESSION['admin_id']=$row1['admin_id'];
         header('Location:admin/dashboard.php');
            }else{
         $message2 = "userName or password is incorrect..";
              echo "<script type='text/javascript'>alert('$message2');window.location= 'index.php';</script>";


            }
          }
          else{
            $message1 = "Account Create First..";
            echo "<script type='text/javascript'>alert('$message1');window.location= 'login.php';</script>";

          }
          }

      }
    }
     ?>
