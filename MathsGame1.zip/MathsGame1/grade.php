<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Anton&display=swap" rel="stylesheet">
	<style>
	.card{
	  width: 220px;
	  height: :300px;
	    border-radius: 30px;
	    box-shadow: 2px 2px 1.5px 1.5px;
	    font-family: 'Baloo Bhai', cursive;
	}

	</style>
 </head>
<body>
	<?php
include("nav.php");
	?>

	<div class="container-fluid" style="margin-top:160px;">
	<div class="row">

	<?PHP

	 $con = mysqli_connect("localhost","rahul","Rahul@123");
	 mysqli_select_db($con,"MathsGame");


	 //if($con){
		//echo "connection succussful";
	 //}else{
	 	//echo "no connection";
	// }


	$query = " SELECT `Question_id`,`Questions`,'opt1','opt2','opt3','opt4',`Images` FROM `Questions` where Question_id ";

	$queryfire = mysqli_query($con, $query);

	$num = mysqli_num_rows($queryfire);

	if($num > 0){
		while($product = mysqli_fetch_array($queryfire)){
			?>

		<div class="col-lg-10 col-md-6 col-sm-12">

			<form>
				<div class="col-lg-10 col-sm-6 col-md-4 mt-2 col-6">
				<p>	<?php echo $product['Questions']; ?></p>

					<div class="container-fluid d-flex justify-content-center mb-5 mt-5">
						<img class="img-fluid" style="width:25%;" src="<?php echo $product['Images']; ?>" alt="bird-Image">
						<img class="img-fluid mt-3 ml-2" style="width:9%; height:2%;" src="images/plusicon.png" alt="plusicon">
						<img class="img-fluid" style="width:25%;" src="<?php echo $product['Images']; ?>" alt="bird-Image">&nbsp
						<img class="img-fluid ml-4" style="width:25%;" src="<?php echo $product['Images']; ?>" alt="bird-Image">

						</div>

					<div class="btnoptions container-fluid d-inline mx-auto center mt-5" style="font">
						<button type="button" style="width:13%;" id="djbtn" class="btnoptions mx-auto btn btn-info mb-2"><b><?php echo $product['opt1'];?></b></button>
						<button type="button" style="width:13%;" id="djbtn" class="btnoptions mx-auto btn btn-info mb-2"><b><?php echo $product['opt2'];?></b></button><br>
						<button type="button" style="width:13%;" id="djbtn" class="btnoptions mx-auto btn btn-info "><b><?php echo $product['opt3'];?></b></button>
						<button type="button" style="width:13%;" id="djbtn" class="btnoptions mx-auto btn btn-info "><b><?php echo $product['opt4'];?></b></button>
					</div>

		    </div>
			</form>
 </br></br>
		</div>


	<?php
		}
	}
	?>


</div>
</body>
</html>
