
<html>
</body>
<form class="form-horizontal" role="form" id='login' method="post" action=".php">
<?php
$number_question = 1;
$row = mysqli_query( $con, "select * from Questions where Operation_id=$Operations");
$rowcount = mysqli_num_rows( $row );
$remainder = $rowcount/$number_question;
$i = 0;
$j = 1; $k = 1;
?>





<?php while ( $result = mysqli_fetch_assoc($row) ) {

              $op1=$result['opt1'];
                $op2=$result['opt2'];
                $op3=$result['opt3'];
                $op4=$result['opt4'];
                echo "<div class='container col-lg-12 col-12'>";
if ( $i == 0) echo "<div class='cont' id='question_splitter_$j'>";?>

<div class="container" id='question<?php echo $k;?>' >

            <p class='questions' style="margin-left:-20px; margin-top:-17px;"  id="qname<?php echo $j;?>"> <?php echo $k?>.&nbsp;&nbsp;&nbsp;<?php echo $result['question_name'];?></p>
            <button type="button" class="collapsible" style="background-color:yellowgreen; color:black; margin-right: -10px; font-size: 1.5vw;font-family:'Metal Mania';border-radius:3px;">Hint</button>
            <div class="content">
              <p id="" style="font-size:25px;"> &nbsp;&nbsp;&nbsp;<?php echo $result['hint'];?> </p>
            </div>
            <?php

if($aid==1){

  ?>

  <input type="radio" value="1" name='<?php echo $result['id'];?>' id='radio1_<?php echo $result['id'];?>' /> <img src="admin/queimg/<?php echo $id; ?>/<?php echo $result['opt1'];?>"width="29%"style="height:140px; border:2px solid ;" alt="">
    <input type="radio" value="2"  name='<?php echo $result['id'];?>' id='radio1_<?php echo $result['id'];?>' /> <img src="admin/queimg/<?php echo $id; ?>/<?php echo $result['opt2'];?>"width="29%"style="height:140px;border:2px solid;" alt=""><br><br>
      <input type="radio" value="3"  name='<?php echo $result['id'];?>' id='radio1_<?php echo $result['id'];?>'/> <img src="admin/queimg/<?php echo $id; ?>/<?php echo $result['opt3'];?>"width="29%"style="height:140px;border:2px solid;" alt="">
        <input type="radio" value="4"  name='<?php echo $result['id'];?>' id='radio1_<?php echo $result['id'];?>'/> <img src="admin/queimg/<?php echo $id; ?>/<?php echo $result['opt4'];?>"width="29%"style="height:140px;border:2px solid;" alt="">

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['Question_id'];?>'/>


<?php
}
if($aid>=2){ ?>
<div class="container" style="font-size:27px; margin-top:30px;">


  <input type="radio" value="1"   id='radio1_<?php echo $result['id'];?>' style="vertical-align:center;" name='<?php echo $result['Question_id'];?>'/>&nbsp;&nbsp;&nbsp;<?php echo $result['op1'];?>

  <input type="radio" value="2"  id='radio1_<?php echo $result['id'];?>'style="vertical-align:center;" name='<?php echo $result['Question_id'];?>'/>&nbsp;&nbsp;&nbsp;<?php echo $result['op2'];?><br><br>

  <input type="radio" value="3"  id='radio1_<?php echo $result['id'];?>'style="vertical-align:center;" name='<?php echo $result['Question_id'];?>'/>&nbsp;&nbsp;&nbsp;<?php echo $result['op3'];?>

  <input type="radio" value="4"  id='radio1_<?php echo $result['id'];?>'style="vertical-align:center;" name='<?php echo $result['Question_id'];?>'/>&nbsp;&nbsp;&nbsp;<?php echo $result['op4'];?>

  <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['Question_id'];?>'/>


</div>
<?php }  ?>
          <!--<input type="radio" value="1" id='radio1_<?php// echo $result['id'];?>' name='<?php //echo $result['id'];?>'/>&nbsp;<?php //echo $result['op1'];?>
            <br/>
<input type="radio" value="2" id='radio1_<?php //echo $result['id'];?>' name='<?php //echo $result['id'];?>'/>&nbsp;<?php //echo $result['op2'];?>
<br/>
<input type="radio" value="3" id='radio1_<?php //echo $result['id'];?>' name='<?php //echo $result['id'];?>'/>&nbsp;<?php //echo $result['op3'];?>
<br/>
<input type="radio" value="4" id='radio1_<?php //echo $result['id'];?>' name='<?php //echo $result['id'];?>'/>&nbsp;<?php //echo $result['op4'];?>
<br/>
<input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php //echo $result['id'];?>' name='<?php //echo $result['id'];?>'/>
<br/>-->

</div>
<br>

<?php
$i++;
if ( ( $remainder < 1 ) || ( $i == $number_question && $remainder == 1 ) ) {
echo "<button  id='".$j."' class='next btn btn-success btn-lg' style='font-size:20px; background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='submit'>Finish</button>";
echo "</div>";

                }  elseif ( $rowcount > $number_question  ) {
if ( $j == 1 && $i == $number_question ) {
echo "<button id='".$j."' class='next btn btn-success btn-lg' style='font-size:20px;background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Next</button>";

echo "</div>";
$i = 0;
$j++;
} elseif ( $k == $rowcount ) {
echo " <button id='".$j."' class='previous btn btn-success btn-lg'style='font-size:20px;background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Previous</button>
<button id='".$j."' class='next btn btn-success btn-lg' style='font-size:20px;background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='submit'>Finish</button>";
echo "</div>";
$i = 0;
$j++;
} elseif ( $j > 1 && $i == $number_question ) {
echo "<button id='".$j."' class='previous btn btn-success btn-lg' style='font-size:20px;background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='button'>Previous</button>
                   <button id='".$j."' class='next btn btn-success btn-lg'style='font-size:20px;background-color:yellowgreen; color:black; font-size: 1.5vw; font-family:'Metal Mania';' type='button' >Next</button>";
echo "</div>";
                  echo "</div>";
$i = 0;
$j++;
}

}
 $k++;
    }
             echo"</div>"?>
</form>
</body>
</html>
