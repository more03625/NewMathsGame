-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 19, 2019 at 03:38 PM
-- Server version: 5.7.27-0ubuntu0.18.04.1
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SpellingMaker`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `id` int(10) NOT NULL,
  `gname` varchar(500) DEFAULT NULL,
  `age_limit` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `gname`, `age_limit`) VALUES
(1, '1 st grade', 'age limit 6 to 7'),
(2, '2 nd grade', 'age limit 7 to 8'),
(3, '3 rd grade', 'age limit 8 to 9'),
(4, '4 th grade', 'age limit 9 to 10');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `lid` int(30) NOT NULL,
  `gid` int(30) NOT NULL,
  `level` varchar(500) DEFAULT NULL,
  `desc` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`lid`, `gid`, `level`, `desc`) VALUES
(1, 2, 'Easy', '( 3 Letters)'),
(2, 2, 'Medium', '( 4 Letters)'),
(3, 2, 'Hard', '( 5 Letters)'),
(5, 3, 'Easy', '( 4 Letters)'),
(6, 3, 'Medium', '( 5 Letters)'),
(7, 3, 'Hard', '( 6  Letters)'),
(8, 4, 'Easy', '( 5 Letters)'),
(9, 4, 'Medium', '(6 Letters)'),
(10, 4, 'Hard', '(7 Letters)'),
(11, 1, 'Start Game', '');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(30) NOT NULL,
  `gid` int(11) NOT NULL,
  `lid` int(30) NOT NULL,
  `que_name` varchar(100) NOT NULL,
  `img` blob NOT NULL,
  `opt1` varchar(50) DEFAULT NULL,
  `opt2` varchar(50) DEFAULT NULL,
  `opt3` varchar(50) DEFAULT NULL,
  `opt4` varchar(50) DEFAULT NULL,
  `op5` varchar(30) DEFAULT NULL,
  `op6` varchar(30) DEFAULT NULL,
  `op7` varchar(30) DEFAULT NULL,
  `correct` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `gid`, `lid`, `que_name`, `img`, `opt1`, `opt2`, `opt3`, `opt4`, `op5`, `op6`, `op7`, `correct`) VALUES
(8, 1, 1, 'Which animal is in the picture ?', 0x646f672e6a7067, 'D', 'O', 'G', '', '', '', '', 'DOG'),
(10, 1, 1, 'Which thing is this ?', 0x626f782e706e67, 'B', 'O', 'X', '', '', '', '', 'BOX'),
(11, 1, 1, 'Which thing is this ?', 0x6b65792e706e67, 'K', 'E', 'Y', '', '', '', '', 'KEY'),
(12, 1, 1, 'Which body part is this ?', 0x6c65672e706e67, 'L', 'E', 'G', '', '', '', '', 'LEG'),
(13, 1, 1, 'Which food is this ?', 0x6567672e706e67, 'E', 'G', 'G', '', '', '', '', 'EGG'),
(14, 1, 1, 'Which bird is this ?', 0x68656e2e6a7067, 'H', 'E', 'N', '', '', '', '', 'HEN'),
(15, 1, 1, 'Which animal is it ?', 0x5261742e706e67, 'R', 'A', 'T', '', '', '', '', 'RAT'),
(16, 1, 1, 'Which insect is in this ?', 0x616e742e706e67, 'A', 'N', 'T', '', '', '', '', 'ANT'),
(17, 1, 1, 'Which body part is this ?', 0x6579652e706e67, 'E', 'Y', 'E', '', '', '', '', 'EYE'),
(18, 1, 1, 'Which thing is this ?', 0x6963652e706e67, 'I', 'C', 'E', '', '', '', '', 'ICE'),
(20, 1, 2, 'Which animal in the picture ?', 0x6c696f6e2e706e67, 'L', 'I', 'O', 'N', '', '', '', 'LION'),
(21, 1, 2, 'Which thing is in image ?', 0x6b6974652e706e67, 'K', 'I', 'T', 'E', '', '', '', 'KITE'),
(22, 1, 2, 'Which thing is this ?', 0x62696b652e6a7067, 'B', 'I', 'K', 'E', '', '', '', 'BIKE'),
(23, 1, 2, 'Which image is this ?', 0x6c6f636b2e706e67, 'L', 'O', 'C', 'K', '', '', '', 'LOCK'),
(24, 1, 2, 'Which body part is this ?', 0x6e6f73652e6a7067, 'N', 'O', 'S', 'E', '', '', '', 'NOSE'),
(25, 1, 2, 'Which color is this ?', 0x70696e6b2e6a7067, 'P', 'I', 'N', 'K', '', '', '', 'PINK'),
(26, 1, 2, 'Which thing is this ?', 0x72696e672e706e67, 'R', 'I', 'N', 'G', '', '', '', 'RING'),
(27, 1, 2, 'Which shape is this ?', 0x737461722e706e67, 'S', 'T', 'A', 'R', '', '', '', 'STAR'),
(28, 1, 2, 'Which thing is this ?', 0x747265652e706e67, 'T', 'R', 'E', 'E', '', '', '', 'TREE'),
(29, 1, 2, 'Which shape is this ?', 0x6d6f6f6e2e706e67, 'M', 'O', 'O', 'N', '', '', '', 'MOON'),
(30, 1, 3, 'Which fruit is it ?', 0x6d616e676f2e706e67, 'M', 'A', 'N', 'G', 'O', '', '', 'MANGO'),
(31, 1, 3, 'Which thing is this ?', 0x77617465722e706e67, 'W', 'A', 'T', 'E', 'R', '', '', 'WATER'),
(32, 1, 3, 'Which food is this ?', 0x62726561642e6a7067, 'B', 'R', 'E', 'A', 'D', '', '', 'BREAD'),
(33, 1, 3, 'Which thing is this ?', 0x636c6f636b2e706e67, 'C', 'L', 'O', 'C', 'K', '', '', 'CLOCK'),
(34, 1, 3, 'Which image is this ?', 0x6379636c652e706e67, 'C', 'Y', 'C', 'L', 'E', '', '', 'CYCLE'),
(35, 1, 3, 'Which device is this ?', 0x70686f6e652e706e67, 'P', 'H', 'O', 'N', 'E', '', '', 'PHONE'),
(36, 1, 3, 'Which image is this ?', 0x63726f776e2e706e67, 'C', 'R', 'O', 'W', 'N', '', '', 'CROWN'),
(37, 1, 3, 'Which thing is this ?', 0x6f6e696f6e2e6a7067, 'O', 'N', 'I', 'O', 'N', '', '', 'ONION'),
(38, 1, 3, 'Which number is it ?', 0x736576656e2e6a7067, 'S', 'E', 'V', 'E', 'N', '', '', 'SEVEN'),
(39, 1, 3, 'Which thing is this ?', 0x726164696f2e706e67, 'R', 'A', 'D', 'I', 'O', '', '', 'RADIO'),
(40, 2, 5, 'Which flower is it ?', 0x726f73652e6a706567, 'R', 'O', 'S', 'E', '', '', '', 'ROSE'),
(41, 2, 5, 'Which cloth is this ?', 0x636f61742e706e67, 'C', 'O', 'A', 'T', '', '', '', 'COAT'),
(42, 2, 5, 'Which animal in this ?', 0x637261622e6a7067, 'C', 'R', 'A', 'B', '', '', '', 'CRAB'),
(43, 2, 5, 'Which thing is this ?', 0x646963652e706e67, 'D', 'I', 'C', 'E', '', '', '', 'DICE'),
(44, 2, 5, 'Which sign in this ?', 0x706c75732e706e67, 'P', 'L', 'U', 'S', '', '', '', 'PLUS'),
(45, 2, 5, 'Which thing is this ?', 0x62616c6c2e706e67, 'B', 'A', 'L', 'L', '', '', '', 'BALL'),
(46, 2, 5, 'What is in image ?', 0x726f61642e6a7067, 'R', 'O', 'A', 'D', '', '', '', 'ROAD'),
(47, 2, 5, 'Which animal in this ?', 0x6475636b2e6a7067, 'D', 'U', 'C', 'K', '', '', '', 'DUCK'),
(48, 2, 5, 'Which image is this ?', 0x77616c6c2e706e67, 'W', 'A', 'L', 'L', '', '', '', 'WALL'),
(49, 2, 5, 'Which thing is this ?', 0x776f6f642e706e67, 'W', 'O', 'O', 'D', '', '', '', 'WOOD'),
(50, 2, 6, 'Which fruit is it ?', 0x6c656d6f6e2e706e67, 'L', 'E', 'M', 'O', 'N', '', '', 'LEMON'),
(51, 2, 6, 'Which flower is it ?', 0x6c6f7475732e706e67, 'L', 'O', 'T', 'U', 'S', '', '', 'LOTUS'),
(52, 2, 6, 'What is in image ?', 0x686f7573652e706e67, 'H', 'O', 'U', 'S', 'E', '', '', 'HOUSE'),
(53, 2, 6, 'What is in image ?', 0x736d696c652e706e67, 'S', 'M', 'I', 'L', 'E', '', '', 'SMILE'),
(54, 2, 6, 'Which animal in this ?', 0x736e616b652e706e67, 'S', 'N', 'A', 'K', 'E', '', '', 'SNAKE'),
(56, 2, 6, 'Which animal in this ?', 0x54696765722e706e67, 'T', 'I', 'G', 'E', 'R', '', '', 'TIGER'),
(58, 2, 6, 'Who is in image ', 0x6e757273652e706e67, 'N', 'U', 'R', 'S', 'E', '', '', 'NURSE'),
(60, 2, 6, 'Which animal is it ?', 0x73686565702e6a7067, 'S', 'H', 'E', 'E', 'P', '', '', 'SHEEP'),
(61, 2, 6, 'Which thing is this ?', 0x676c6173732e706e67, 'G', 'L', 'A', 'S', 'S', '', '', 'GLASS'),
(62, 2, 6, 'Which thing is this ?', 0x636861696e2e706e67, 'C', 'H', 'A', 'I', 'N', '', '', 'CHAIN'),
(63, 2, 7, 'Which animal is it ?', 0x747572746c652e706e67, 'T', 'U', 'R', 'T', 'L', 'E', '', 'TURTLE'),
(64, 2, 7, 'Which image is this ?', 0x67617264656e2e706e67, 'G', 'A', 'R', 'D', 'E', 'N', '', 'GARDEN'),
(65, 2, 7, 'What is in image ?', 0x636f666665652e706e67, 'C', 'O', 'F', 'F', 'E', 'E', '', 'COFFEE'),
(66, 2, 7, 'Which food is this ?', 0x6275747465722e706e67, 'B', 'U', 'T', 'T', 'E', 'R', '', 'BUTTER'),
(67, 2, 7, 'Which animal is it ?', 0x7261626269742e6a7067, 'R', 'A', 'B', 'B', 'I', 'T', '', 'RABBIT'),
(68, 2, 7, 'Which thing is this ?', 0x63616d6572612e706e67, 'C', 'A', 'M', 'E', 'R', 'A', '', 'CAMERA'),
(69, 2, 7, 'What is in image ?', 0x627574746f6e2e706e67, 'B', 'U', 'T', 'T', 'O', 'N', '', 'BUTTON'),
(70, 2, 7, 'What is in image ?', 0x656e67696e652e706e67, 'E', 'N', 'G', 'I', 'N', 'E', '', 'ENGINE'),
(71, 2, 7, 'Which animal is it ?', 0x6d6f6e6b65792e6a7067, 'M', 'O', 'N', 'K', 'E', 'Y', '', 'MONKEY'),
(72, 2, 7, 'What is in image ?', 0x6272696467652e706e67, 'B', 'R', 'I', 'D', 'G', 'E', '', 'BRIDGE'),
(73, 3, 9, 'Who is in image ?', 0x6661726d6572202831292e6a7067, 'F', 'A', 'R', 'M', 'E', 'R', '', 'FARMER'),
(74, 3, 9, 'Which thing is this ?', 0x6275636b65742e706e67, 'B', 'U', 'C', 'K', 'E', 'T', '', 'BUCKET'),
(75, 3, 9, 'Which shape is it ?', 0x737175617265202831292e706e67, 'S', 'Q', 'U', 'A', 'R', 'E', '', 'SQUARE'),
(76, 3, 9, 'Which body part is it ?', 0x66696e676572202831292e6a7067, 'F', 'I', 'N', 'G', 'E', 'R', '', 'FINGER'),
(77, 3, 9, 'Which animal is it ?', 0x647261676f6e202831292e706e67, 'D', 'R', 'A', 'G', 'O', 'N', '', 'DRAGON'),
(78, 3, 9, 'Which thing is this ?', 0x72656d6f7465202831292e706e67, 'R', 'E', 'M', 'O', 'T', 'E', '', 'REMOTE'),
(79, 3, 9, 'Which image is it ?', 0x6d6f62696c652e706e67, 'M', 'O', 'B', 'I', 'L', 'E', '', 'MOBILE'),
(80, 3, 10, 'Which person is it ?', 0x706f73746d616e2e6a7067, 'P', 'O', 'S', 'T', 'M', 'A', 'N', 'POSTMAN'),
(81, 3, 10, 'Which animal is it ?', 0x6c656f706172642e706e67, 'L', 'E', 'O', 'P', 'A', 'R', 'D', 'LEOPARD'),
(82, 3, 10, 'Which food is this ?', 0x636f6f6b6965732e706e67, 'C', 'O', 'O', 'K', 'I', 'E', 'S', 'COOKIES'),
(83, 3, 10, 'Which thing is this ?', 0x766f6c63616e6f2e6a706567, 'V', 'O', 'L', 'C', 'A', 'N', 'O', 'VOLCANO'),
(84, 3, 10, 'Which animal is it ?', 0x62756666616c6f202831292e706e67, 'B', 'U', 'F', 'F', 'A', 'L', 'O', 'BUFFALO'),
(85, 3, 10, 'What is in image ?', 0x63616262616765202831292e6a7067, 'C', 'A', 'B', 'B', 'A', 'G', 'E', 'CABBAGE'),
(86, 3, 10, 'Which animal is it ?', 0x6f63746f707573202831292e6a7067, 'O', 'C', 'T', 'O', 'P', 'U', 'S', 'OCTOPUS'),
(88, 3, 8, 'Which animal is it ?', 0x7768616c65202831292e6a7067, 'W', 'H', 'A', 'L', 'E', '', '', 'WHALE'),
(89, 3, 8, 'What is in image ?', 0x73686972742e706e67, 'S', 'H', 'I', 'R', 'T', '', '', 'SHIRT'),
(90, 3, 8, 'Which number is it ?', 0x65696768742e706e67, 'E', 'I', 'G', 'H', 'T', '', '', 'EIGHT'),
(91, 3, 8, 'What is in image ?', 0x66726f636b2e6a706567, 'F', 'R', 'O', 'C', 'K', '', '', 'FROCK'),
(92, 3, 8, 'Which image is this ?', 0x67726173732e6a706567, 'G', 'R', 'A', 'S', 'S', '', '', 'GRASS'),
(93, 3, 8, 'Which animal is it ?', 0x4d6f7573652e706e67, 'M', 'O', 'U', 'S', 'E', '', '', 'MOUSE'),
(94, 3, 8, 'What is in image ?', 0x73706f6f6e2e6a706567, 'S', 'P', 'O', 'O', 'N', '', '', 'SPOON'),
(95, 3, 8, 'Which animal is it ?', 0x5268696e6f2e6a7067, 'R', 'H', 'I', 'N', 'O', '', '', 'RHINO'),
(96, 3, 8, 'What is in image ?', 0x746f776572202831292e706e67, 'T', 'O', 'W', 'E', 'R', '', '', 'TOWER'),
(97, 3, 8, 'Which fruit is it ?', 0x62657272792e6a706567, 'B', 'E', 'R', 'R', 'Y', '', '', 'BERRY'),
(98, 3, 9, 'Which food is this ?', 0x6275726765722e706e67, 'B', 'U', 'R', 'G', 'E', 'R', '', 'BURGER'),
(99, 3, 9, 'Which animal is it ?', 0x646f6e6b65792e706e67, 'D', 'O', 'N', 'K', 'E', 'Y', '', 'DONKEY'),
(100, 3, 9, 'Which food is this ?', 0x6368656573652e706e67, 'C', 'H', 'E', 'E', 'S', 'E', '', 'CHEESE'),
(101, 3, 10, 'Which thing is this ?', 0x6c6962726172792e706e67, 'L', 'I', 'B', 'R', 'A', 'R', 'Y', 'LIBRARY'),
(102, 4, 10, 'Which image is this ?', 0x6b69746368656e2e706e67, 'K', 'I', 'T', 'C', 'H', 'E', 'N', 'KITCHEN'),
(103, 4, 10, 'What is in image ?', 0x70756d706b696e2e706e67, 'P', 'U', 'M', 'P', 'K', 'I', 'N', 'PUMPKIN'),
(104, 1, 11, 'What is in image ?', 0x73756e2e706e67, 'S', 'U', 'N', '', '', '', '', 'SUN'),
(105, 1, 11, 'What is in image ?', 0x7475622e706e67, 'T', 'U', 'B', '', '', '', '', 'TUB'),
(106, 1, 11, 'Which number is it ?', 0x74656e2e706e67, 'T', 'E', 'N', '', '', '', '', 'TEN'),
(107, 1, 11, 'Which color is this ?', 0x7265642e706e67, 'R', 'E', 'D', '', '', '', '', 'RED'),
(108, 1, 11, 'What is in image ?', 0x706f742e706e67, 'P', 'O', 'T', '', '', '', '', 'POT'),
(109, 1, 11, 'Which bird is this ?', 0x6f776c2e6a7067, 'O', 'W', 'L', '', '', '', '', 'OWL'),
(110, 1, 11, 'What is in image ?', 0x6d75672e706e67, 'M', 'U', 'G', '', '', '', '', 'MUG'),
(111, 1, 11, 'Which number is it ?', 0x7369782e706e67, 'S', 'I', 'X', '', '', '', '', 'SIX'),
(112, 1, 11, 'What is in image ?', 0x6a61722e706e67, 'J', 'A', 'R', '', '', '', '', 'JAR'),
(113, 1, 11, 'What is in image ?', 0x7461702e706e67, 'P', 'E', 'N', '', '', '', '', 'PEN');

-- --------------------------------------------------------

--
-- Table structure for table `score`
--

CREATE TABLE `score` (
  `id` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_score` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `score`
--

INSERT INTO `score` (`id`, `lid`, `name`, `user_score`) VALUES
(1, 1, 'Pratiksha', '9'),
(2, 1, 'Pratiksha', '9'),
(3, 1, 'Pratiksha', '9'),
(4, 1, 'Pratiksha', '9'),
(5, 1, 'Pratiksha', '9'),
(6, 1, 'Pratiksha', '9'),
(7, 1, 'Pratiksha', '9'),
(8, 1, 'Pratiksha', '9'),
(9, 1, 'Pratiksha', '9'),
(10, 1, 'Pratiksha', '9'),
(11, 1, 'Pratiksha', '9'),
(12, 1, 'Pratiksha', '9'),
(13, 1, 'Pratiksha', '9'),
(14, 1, 'Pratiksha', '9'),
(15, 1, 'Pratiksha', '9'),
(16, 1, 'Pratiksha', '9'),
(17, 1, 'Pratiksha', '9'),
(18, 1, 'Pratiksha', '9'),
(19, 1, 'Pratiksha', '9'),
(20, 1, 'Pratiksha', '9'),
(21, 1, 'Pratiksha', '9'),
(22, 1, 'Pratiksha', '9'),
(23, 1, 'Pratiksha', '9'),
(24, 1, 'Pratiksha', '9'),
(25, 1, 'Pratiksha', '9'),
(26, 1, 'Pratiksha', '9'),
(27, 1, 'Pratiksha', '9'),
(28, 2, 'Pratiksha', '9'),
(29, 2, 'Pratiksha', '9'),
(30, 2, 'Pratiksha', '0'),
(31, 1, 'Pratiksha', '0'),
(32, 1, 'Pratiksha', '0'),
(33, 1, 'Pratiksha', '0'),
(34, 1, 'Pratiksha', '0'),
(35, 1, 'Pratiksha', '0'),
(36, 1, 'Pratiksha', '0'),
(37, 1, 'Pratiksha', '0'),
(38, 2, 'Pratiksha', '0'),
(39, 2, 'Pratiksha', '0'),
(40, 2, 'Pratiksha', '0'),
(41, 2, 'Pratiksha', '0'),
(42, 2, 'Pratiksha', '0'),
(43, 2, 'Pratiksha', '0'),
(44, 2, 'Pratiksha', '0'),
(45, 2, 'Pratiksha', '0'),
(46, 2, 'Pratiksha', '0'),
(47, 2, 'Pratiksha', '0'),
(48, 2, 'Pratiksha', '0'),
(49, 2, 'Pratiksha', '0'),
(50, 2, 'Pratiksha', '0'),
(51, 2, 'Pratiksha', '0'),
(52, 2, 'Pratiksha', '0'),
(53, 2, 'Pratiksha', '0'),
(54, 2, 'Pratiksha', '0'),
(55, 2, 'Pratiksha', '0'),
(56, 2, 'Pratiksha', '0'),
(57, 2, 'Pratiksha', '0'),
(58, 1, 'Pratiksha', '0'),
(59, 2, 'Pratiksha', '0'),
(60, 2, 'Pratiksha', '0'),
(61, 3, 'Pratiksha', '0'),
(62, 3, 'Pratiksha', '0'),
(63, 5, 'Pratiksha', '0'),
(64, 5, 'Pratiksha', '0'),
(65, 5, 'Pratiksha', '0'),
(66, 6, 'Pratiksha', '0'),
(67, 6, 'Pratiksha', '0'),
(68, 6, 'Pratiksha', '0'),
(69, 6, 'Pratiksha', '0'),
(70, 6, 'Pratiksha', '0'),
(71, 1, 'Pratiksha', '0'),
(72, 2, 'Pratiksha', '0'),
(73, 5, 'Pratiksha', '0'),
(74, 6, 'Pratiksha', '0'),
(75, 6, 'Pratiksha', '0'),
(76, 2, 'Pratiksha', '0'),
(77, 1, 'Pratiksha', '0'),
(78, 2, 'Pratiksha', '0'),
(79, 2, 'Pratiksha', '0'),
(80, 3, 'Pratiksha', '0'),
(81, 5, 'Pratiksha', '0'),
(82, 5, 'Pratiksha', '0'),
(83, 5, 'Pratiksha', '0'),
(84, 6, 'Pratiksha', '0'),
(85, 7, 'Pratiksha', '0'),
(86, 6, 'Pratiksha', '0'),
(87, 5, 'Pratiksha', '0'),
(88, 7, 'Pratiksha', '0'),
(89, 7, 'Pratiksha', '0'),
(90, 6, 'Pratiksha', '0'),
(91, 6, 'Pratiksha', '0'),
(92, 7, 'Pratiksha', '0'),
(93, 7, 'Pratiksha', '0'),
(94, 7, 'Pratiksha', '0'),
(95, 7, 'Pratiksha', '0'),
(96, 9, 'neha', '0'),
(97, 9, 'neha', '0'),
(98, 9, 'neha', '0'),
(99, 9, 'neha', '0'),
(100, 9, 'neha', '0'),
(101, 9, 'neha', '0'),
(102, 9, 'neha', '0'),
(103, 10, 'neha', '0'),
(104, 10, 'neha', '0'),
(105, 8, 'neha', '0'),
(106, 9, 'neha', '0'),
(107, 9, 'neha', '0'),
(108, 10, 'neha', '0'),
(109, 9, 'neha', '0'),
(110, 11, 'neha', '0'),
(111, 11, 'neha', '0'),
(112, 1, 'neha', '0'),
(113, 11, 'neha', '0'),
(114, 11, 'neha', '0'),
(115, 5, 'neha', '0'),
(116, 1, 'neha', '0'),
(117, 2, 'neha', '0'),
(118, 3, 'neha', '0'),
(119, 1, 'neha', '0'),
(120, 1, 'neha', '0'),
(121, 2, 'neha', '0'),
(122, 3, 'neha', '0'),
(123, 5, 'neha', '0'),
(124, 1, 'neha', '0'),
(125, 1, 'neha', '0'),
(126, 10, 'neha', '0'),
(127, 3, 'neha', '0'),
(128, 11, 'neha', '0'),
(129, 11, 'neha', '0'),
(130, 11, 'neha', '0'),
(131, 11, 'Pratiksha', '0'),
(132, 2, 'Pratiksha', '0'),
(133, 2, 'Pratiksha', '0'),
(134, 1, 'kajal', '0'),
(135, 2, 'kajal', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `mobile`, `pass`) VALUES
(1, 'Pratiksha', 'pratiksha@gmail.com', 8676435353, '1234'),
(3, 'neha', 'neha@gmail.com', 8676435353, '1234'),
(5, 'hemant', 'hemant@gmail.com', 8676435353, '123456'),
(7, 'kajal', 'kajal@gmail.com', 8709123451, '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `score`
--
ALTER TABLE `score`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `lid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `score`
--
ALTER TABLE `score`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
