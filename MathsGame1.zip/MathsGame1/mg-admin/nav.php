<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Cabin+Sketch&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="student_image/pratham.jpeg">
    <link href='https://fonts.googleapis.com/css?family=Metal Mania' rel='stylesheet'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
      <link href="https://fonts.googleapis.com/css?family=Permanent+Marker&display=swap" rel="stylesheet">
        <!-- <?php
         // session_start();
         ?> -->
      <style media="screen">

      .artical{background-image:url("image/DSC100399901.jpg");
        width:101vw;
      height:80vh;


    }

      body {
    font-family: 'Metal Mania';font-size: 22px;
}
      .form{
      background-color:rgba(255,0,255,0.4);
      margin-top:4vh;height:70vh;
    }


      .h{
        font-family: 'Metal Mania';font-size: 30px;   color: #00bacc;


      }
      #head{
        font-family: 'Metal Mania';font-size: 80px;

      }

      </style>
  </head>

  <body>
    <!-- <?php

   // if(!isset($_SESSION['admin_id'])){
   //   header('Location: ../index.php');
   }

   ?> -->

   <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to bottom right, #0099cc 1%, #99ffcc 100%);">
     <div class="col-lg-3 col-4">
          <a class="navbar-brand" href="index.php">
            <img src="pra.png" class="img-fluid mb-1" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-5">
            <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:blue">Maths<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Game</span></h1>
        </div>
        <div class="col-lg-2 col-3" >
          <form class="form-colntrol" action="logout.php" method="post">
                  <?php
                                    session_start();
                                    error_reporting(0);
                                    if (strlen($_SESSION['user_id'])>=0) {
                                      echo "<a href='logout.php' class='btn btn-success' style='font-family: Georgia; color:white; font-size:20px;'>Logout</a>";
                                    } else {
                                        echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Metal Mania';' name='logout' value='Logout'>";
                                    }
                                     ?>
                                   </form>
          <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
        </div>

      </nav>







  </body>
</html>
