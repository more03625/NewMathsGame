<?php
$servername = "localhost";
$username = "rahul";
$password = "Rahul@123";
$dbname = "quiz2";

$conn =mysqli_connect($servername, $username, $password, $dbname)or die;
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}else {
  // $grade=$_POST['grad'];
  // $category=$_POST['category'];
  //
  // $question=$_POST['qname'];
  //
  // $op1=$_POST['op1'];
  // $op2=$_POST['op2'];
  // $op3=$_POST['op3'];
  // $op4=$_POST['op4'];
  //
  $cans=$_POST['crt'];

// $_FILES from here
  // $name = $_POST['file']['name'];
  $img1=$_POST['getimg'];
  $img2=$_POST['file1'];
  $img3=$_POST['file2'];
  $img4=$_POST['file3'];

  $img5=$_POST['file4'];
  $img6=$_POST['file5'];

// echo $grade."<br>";
// echo $category."<br>";
// echo $question."<br>";
// echo $op1."<br>";
// echo $op2."<br>";
// echo $op3."<br>";
// echo $op4."<br>";
// echo $cans."<br>";
// echo $img1."<br>";
// echo $img2."<br>";
// echo $img3."<br>";
// echo $img4."<br>";
// echo $img5."<br>";
// echo $img6."<br>";


  // $img=$_FILES['img'];
  // $target_dir = "queimg/$lid";
  // $target_file = $target_dir . basename($_FILES["file"]["name"]);

 // Insert record
 // $query = "INSERT INTO question VALUES('$grade','$category','$question','$op1','$op2','$op3','$op4','$cans','$img1','$img2','$img3','$img4','$img5','$img6')";
 //
 //  if (mysqli_query($conn,$query)) {
 //    header('Location:questions.php?msg=Questions added succesfully...');
 //      // move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
 //  }else {
 //    header('Location:questions.php?msg=Question Adding faild');
 //  }
}


?>
