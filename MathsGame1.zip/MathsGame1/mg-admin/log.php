<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<style>

</style>
<body>

<div class="container-fluid">
  <center><h3>Login</h3></center>
  <div class="row">
    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4"></div>

  <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4 card bg-info text-white m-3" style="width:350px"><br>
    <img class="card-img-top mx-auto d-block" src="images/log.png" alt="Card image" style="width:40%">



    <div class="card-body">
  <form class="form" action="loginfetch.php" method="post">
    <div class="form-group">


  <label for="email">Email address:</label>
  <input type="email" class="form-control" name="email">


  <label for="pwd">Password:</label>
  <input type="password" class="form-control" name="password"><br>

  <button type="submit" class="btn btn-primary">Login</button>
</form>
</div>
      </div>
  </div></div>
</div></div>
  <br>
  <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4"></div>



</body>
</html>
