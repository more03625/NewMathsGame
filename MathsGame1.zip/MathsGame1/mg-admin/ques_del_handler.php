<?php


$conn=mysqli_connect("localhost","riya","riya123","quiz");

if (isset($_POST['ques_delete'])) {


  $ques=$_POST['question'];

  $sql="DELETE from question where id='$ques'";
  $result=mysqli_query($conn,$sql);

  if ($result) {
    $message1 = "question deleted succesfully.";
    echo "<script type='text/javascript'>confirm('$message1');window.location= 'question.php';</script>";

  }else {
    $message2= "question not deleted.";
    echo "<script type='text/javascript'>alert('$message2');window.location= 'question.php';</script>";

  }
}


 ?>
