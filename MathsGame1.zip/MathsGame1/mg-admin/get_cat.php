<?php

$conn=mysqli_connect("localhost","riya","riya123","quiz");
if(!empty($_POST["id"]))
{
 $id=intval($_POST['id']);
 $sql = "select * from level WHERE gid=$id";

$query=mysqli_query($conn,$sql);
echo "<option>Select Level</option>";
 while($row=mysqli_fetch_array($query))
 {
  ?>
  <?php echo $var ?>
  <option value="<?php echo htmlentities($row['lid']); ?>"><?php echo htmlentities($row['level']); ?></option>
  <?php
 }
}
?>
