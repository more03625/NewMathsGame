<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

   <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>




   <style media="screen">

   .artical{background-image:url("image/DSC100399901.jpg");
     width:101vw;
   height:80vh;


   }

   body {
   font-family: 'Metal Mania';font-size: 22px;
   }
   .form{
   background-color:rgba(255,0,255,0.4);
   margin-top:4vh;height:70vh;
   }


   .h{
     font-family: 'Metal Mania';font-size: 30px;   color: #00bacc;


   }
   #head{
     font-family: 'Metal Mania';font-size: 80px;

   }

   </style>





    <title></title>
  </head>
  <body>




    <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to right, #ffffff 17%, #ffccff 100%);">
        <div class="col-lg-3 col-4">
          <a class="navbar-brand" href="index.php">
            <img src="pra.png" class="img-fluid mb-1" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-5">
            <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:blue">Maths<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Game</span></h1>
        </div>
        <div class="col-lg-2 col-3" >
          <form class="form-colntrol" action="logout.php" method="post">
                  <?php
                                    session_start();
                                    error_reporting(0);
                                    if (strlen($_SESSION['user_id'])>=0) {
                                      echo "<a href='logout.php' class='btn btn-success' style='font-family: Georgia; color:white; font-size:20px;'>Logout</a>";
                                    } else {
                                        echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Metal Mania';' name='logout' value='Logout'>";
                                    }
                                     ?>
                                   </form>
          <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
        </div>

      </nav>









    <div style="background-color:#F29C94;"><br>
    <center><h1> Add Grade</h1></center>

     <!--Side Nav-->

          <?php include("sidenav.php"); ?>
    <form class="card-body" id="big" action="questions_handler.php" method="post" enctype="multipart/form-data">
            <br><br>
            <center>
              <div class="form-group row">
              <label for=""class="col-lg-3 py-2">Grade</label>
              <select class="form-control col-lg-9" name="grad"  id="category" onchange="getSubcat(this.value);" required>

    <option value="">Select Grade</option>
                <?php

                $conn=mysqli_connect("localhost","rahul","Rahul@123","quiz2");
                     $sql = "SELECT *from Grade";
                     $res = mysqli_query($conn,$sql);
                     while ($record = mysqli_fetch_assoc($res)) {
                       $id = $record['Grade_id'];
                       $name = $record['Grade_name'];
                       echo "<option value='$id'>$name</option>";
                     }
                    ?>
              </select>
            </div>

            <!-- <script type="text/javascript">
                 function getSubcat(val) {
                   $.ajax({
                   type: "POST",
                   url: "get_cat.php",
                   data:'id='+val,
                   success: function(data){
                     $("#subcategory").html(data);
                   }
                   });
                   }
                  </script> -->
                  <div class="form-group row">
                           <label for="" class="col-lg-3 py-2">Category_id</label>
                           <select class="form-control col-lg-9" name="category" id="subcategory">
                             <option value="">Select Category</option>
                             <?php

                             $conn=mysqli_connect("localhost","rahul","Rahul@123","quiz2");
                                  $sql = "SELECT *from category";
                                  $res = mysqli_query($conn,$sql);
                                  while ($record = mysqli_fetch_assoc($res)) {
                                    $id = $record['cid'];
                                    $name = $record['category'];
                                    echo "<option value='$id'>$name</option>";
                                  }
                                 ?>

                           </select>
                         </div>

                          <div class="form-group row">
                             <label class="col-lg-3">Question Name</label>
                             <input type="text" name="qname" value="" class="form-control col-lg-9" placeholder="Enter Your Question">
                           </div>

                           <div class="form-group row">
                             <label class="col-lg-3">Option 1</label>
                             <input type="text" name="op1" value="" class="form-control col-lg-9" placeholder="Enter first letter">
                           </div>

                           <div class="form-group row">
                             <label class="col-lg-3">Option 2</label>
                             <input type="text" name="op2" value="" class="form-control col-lg-9" placeholder="Enter second letter">
                           </div>

                           <div class="form-group row">
                             <label class="col-lg-3">Option 3</label>
                             <input type="text" name="op3" value="" class="form-control col-lg-9" placeholder="Enter third letter">
                           </div>
                           <div class="form-group row">
                             <label class="col-lg-3">Option 4</label>
                             <input type="text" name="op4" value="" class="form-control col-lg-9" placeholder="Enter fourth letter">
                           </div>

                           <div class="form-group row">
                             <label class="col-lg-3">Correct Answer</label>
                             <input type="text" name="crt" value="" class="form-control col-lg-9" placeholder="Enter Correct Answer">
                           </div>

                           <!-- <div class="form-group row">
                             <label class="col-lg-3">image</label>
                             <input type="file" name="file" value="" class="form-control col-lg-9" placeholder="Enter image">
                           </div> -->

                           <input type="file" name="getimg" value="">
                           
                         <button type="submit" name="save" class="btn btn-dark text-light">Insert</button><br><br>
                       </center>

          </form>



</div>

</div>
<div class="">
  <footer class="bg-secondary text-light text-center"> Copyright 2019 By Pratham InfoTech Foundation</footer>
</div>
</div>



  </body>
</html>
