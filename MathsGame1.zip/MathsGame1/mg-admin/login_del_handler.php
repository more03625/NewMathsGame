<?php


$conn=mysqli_connect("localhost","riya","riya123","quiz");

if (isset($_POST['user_delete'])) {

$email=$_POST['email'];

$sql="DELETE from signup where email_id='$email'";
$result=mysqli_query($conn,$sql);

if ($result) {
  $message1 = "User delete succesfully.";
  echo "<script type='text/javascript'>confirm('$message1');window.location= 'user.php';</script>";

}else {
  $message2 = "User Not  deleted .";
  echo "<script type='text/javascript'>alert('$message2');window.location= 'user.php';</script>";

}

}






 ?>
