<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="imghand.php" method="post">
      <input type="file" name="getimg" value="">
      <button type="submit" name="button">Submit</button>
    </form>
  </body>
</html>
