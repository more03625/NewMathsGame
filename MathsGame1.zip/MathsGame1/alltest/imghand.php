<?php
session_start();

$host       = "localhost";
$dbusername = "rahul";
$dbpass     = "Rahul@123";
$dbname     = "EverythingTest";
$conn      = mysqli_connect($host, $dbusername, $dbpass, $dbname);


$conn=mysqli_connect($host, $dbusername, $dbpass, $dbname);
 if(!$conn){
die("connection failed:".mysqli_connect_error());
}

$image = $_POST['getimg'];
// echo "$image";

$query = "INSERT INTO images(images) VALUES ('$image')";
$result = mysqli_query($conn,$query);

if ($result) {
  echo "images inserted succesfully";
}else {
  echo "failed";
}

?>
