<?php
include 'log.php';
session_start();
$host       = "localhost";
$dbusername = "rahul";
$dbpass     = "Rahul@123";
$dbname     = "quiz2";
$conn      = mysqli_connect($host, $dbusername, $dbpass, $dbname);

if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

$email=$_POST["email"];
$password=$_POST["password"];

  $sql="SELECT * FROM admin WHERE email ='$email' AND password ='$password'";
  $result =mysqli_query($conn,$sql);

  if(mysqli_num_rows($result)==1){
    $_SESSION["admin"] = $email;
    echo "<script>alert('Login Successfully');
          window.location.href='dashboard.php';
        </script>";
  }
  else {
    echo "<script>alert('Sorry,Invalid Email and Password');
          window.location.href='log.php';
        </script>";
  }
 ?>
