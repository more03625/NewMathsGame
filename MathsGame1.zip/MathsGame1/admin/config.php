<?php
session_start();

$host       = "localhost";
$dbusername = "rahul";
$dbpass     = "Rahul@123";
$dbname     = "quiz2";
$conn      = mysqli_connect($host, $dbusername, $dbpass, $dbname);


$conn=mysqli_connect($host, $dbusername, $dbpass, $dbname);
 if(!$conn){
die("connection failed:".mysqli_connect_error());
}
?>
