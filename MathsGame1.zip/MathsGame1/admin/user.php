<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="student_image/pratham.jpeg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </head>

  <body>
    <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to right, #ffffff 17%, #ffccff 100%);">
        <div class="col-lg-3 col-4">
          <a class="navbar-brand" href="index.php">
            <img src="pra.png" class="img-fluid mb-1" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-5">
            <h1 class="align-bottom pl-2" style="font-size:4vw;font-family: 'Lobster', cursive;color:blue">Maths<span style="font-family: 'Lobster', cursive;color:blue;font-size:4vw;">Game</span></h1>
        </div>
        <div class="col-lg-2 col-3" >
          <form class="form-colntrol" action="logout.php" method="post">
                  <?php
                                    session_start();
                                    error_reporting(0);
                                    if (strlen($_SESSION['user_id'])>=0) {
                                      echo "<a href='logout.php' class='btn btn-success' style='font-family: Georgia; color:white; font-size:20px;'>Logout</a>";
                                    } else {
                                        echo "<input type='submit' class='btn ' style='background-color:yellowgreen;font-family: 'Metal Mania';' name='logout' value='Logout'>";
                                    }
                                     ?>
                                   </form>
          <!-- <a href="logout.php" class="btn" style="background-color:yellowgreen;font-family: 'Metal Mania';">Logout</a> -->
        </div>

      </nav>
    <div style="background-color:#F29C94;"><br>
    <center><h1> User </h1></center>

     <!--Side Nav-->
    <?php include("sidenav.php"); ?>
<br>
       </div>


<div class="col-lg-8 col-12">
  <table class="table table-bordered table-responsive blue">
    <thead class="thead-light">
      <tr>
        <th scope="col">Sr.NO</th>
        <th scope="col"> User Name</th>
        <th scope="col">user Score</th>
        <th scope="col">category id</th>
        <th scope="col">Delete</th>
        <!-- <th scope="col">Operate</th> -->
      </tr>
    </thead>
    <tbody>
      <?php

      $conn=mysqli_connect("localhost","rahul","Rahul@123","quiz2");
                    $sql="select * from users";
                    $result=mysqli_query($conn,$sql);
                    $row = mysqli_affected_rows($conn);
                    if ($result == True) {
                      $i=1;
                      while ($record=mysqli_fetch_assoc($result)) {
                          echo "<tr>";
                          $id = $record['user_id'];

                          echo "<td>".$i."</td>";
                          echo "<td>".$record['user_name']."</td>";
                          echo "<td>".$record['user_score']."</td>";
                          echo "<td>".$record['cid']."</td>";
                          // echo "<td>".$record['city']."</td>";
                          echo "<td><a data-toggle='modal' data-target='#myModal' > <i class='fa fa-trash'></i></a></td>";
                          echo "</tr>";
                          $i++;
                     }
                    }
                   ?>
    </tbody>
  </table>





</div>






       </div>
</div>

     </div>
     <div class="">
       <footer class="bg-secondary text-light text-center"> Copyright 2019 By Pratham InfoTech Foundation</footer>
     </div>







           <div class="modal" id="myModal">
             <div class="modal-dialog">
               <div class="modal-content">


                 <div class="modal-header"style="background-color:skyblue;">

                   <button type="button" class="close" data-dismiss="modal">&times;</button>
                 </div>


                 <div class="modal-body"style="background-color:lightpink;">

     <div class="container">

                   <div class="row">
                     <div class="col-lg-12 col-12">
                       <form class="form" action="login_del_handler.php" method="post">
                         <h1>User Delete</h1><br>
                         <label for="email">Name:</label>
                         <input type="email" class="form-control" name="email" placeholder="User Name" value=""style="border-radius:10px;"><br>
                         <input type="submit" name="user_delete" value="Delete"style="border-radius:10px;">
                       </form>
                     </div>


                 </div>



               </div>
             </div>
           </div>

         </div>
       </div>






  </body>
</html>
