<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div id='timer'>
      <?php //include("timer.php"); ?>
        <script type="application/javascript">
        var myCountdownTest = new Countdown({
                                time: 120,
                                width:200,
                                height:80,
                                rangeHi:"minute"
                                });
       </script>

    </div>
  </body>
</html>
