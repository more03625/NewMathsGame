<?php
$servername ="localhost";
$username = "rahul";
$password = "Rahul@123";
$dbname = "quiz2";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if (!$conn) {
  die("Connection failed:". mysqli_connect_error());
}

$fname=$_POST['name'];
$email=$_POST['email'];
$pass=$_POST['pwd'];

$sql = "insert into signup(Name,email_id,password) values('$fname','$email','$pass')";

if (mysqli_query($conn, $sql)) {
  echo "<script>alert('Successfully Register For Website!!!');
  window.location.href='login.php';

  </script>";
}else{
  echo "Error:".$sql. "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
