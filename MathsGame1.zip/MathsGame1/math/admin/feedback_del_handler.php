<?php

$conn=mysqli_connect("localhost","root","","quiz");

if (isset($_POST['feed_delete'])) {


  $name=$_POST['name'];

  $sql="DELETE from feedback where name='$name'";
  $result=mysqli_query($conn,$sql);

  if ($result) {
    $message1 = "Feedback deleted succesfully.";
    echo "<script type='text/javascript'>confirm('$message1');window.location= 'feedback.php';</script>";

  }else {
    $message2= "Feedback not deleted.";
    echo "<script type='text/javascript'>alert('$message2');window.location= 'feedback.php';</script>";

  }
}


 ?>
