<?php

$conn=mysqli_connect("localhost","pratiksha","Pari@123","SpellingMaker");

if (isset($_POST['age_delete'])) {
  $age=$_POST['age'];

  $sql="DELETE from grade where age_group='$age'";

  $result=mysqli_query($conn,$sql);
if ($result) {
  $message1 = "Age deleted succesfully.";
  echo "<script type='text/javascript'>confirm('$message1');window.location= 'agegroup.php';</script>";

}else {
  $message2 = "Age not deleted.";
  echo "<script type='text/javascript'>alert('$message2');window.location= 'agegroup.php';</script>";

}


}


 ?>
