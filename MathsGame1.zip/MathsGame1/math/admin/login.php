<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <style >

body{
   background:  linear-gradient(to bottom, #00ccff 42%, #669900 91%);
  /* background-image:url('img/new3.jpg' );

    background-repeat: no-repeat;
    background-size: cover;
    background-position: fixed; */
}
</style>
<body>
  <?php
 require 'nav1.php';
   ?>
   <br>
   <div class="container" style="width:70vh;margin-top:80px">

  <!--Content-->
  <div class="modal-content">

    <!--Modal cascading tabs-->
    <div class="modal-c-tabs">

      <!-- Nav tabs -->


      <!-- Tab panels -->
      <div class="tab-content">
        <!--Panel 7-->
        <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

          <!--Body-->
          <div class="card" style="background: linear-gradient(to bottom right, #0099cc 0%, #99ffcc 100%);">

          <div class="card-header" style="color:white">
            <h3>Login</h3>
          </div>
          <div class="card-body">
            <form action="loginfetch.php" method="POST">
              <div class="input-group form-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fa fa-user"></i></span>
                </div>
                <input type="text" class="form-control" name="email" placeholder="username">

              </div>
              <div class="input-group form-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fa fa-key"></i></span>
                </div>
                <input type="password" class="form-control" name="password" placeholder="password">
              </div>
              <div class="form-group" align='center'>
                <button type="submit" value="Login" class="btn btn-lg" style="background-color:#11B0D0;color:white">Login</button>
              </div>
            </form>
          </div>


        </div>
        </div>
        <!--/.Panel 7-->

        <!--Panel 8-->

      </div>
    </div>
  </div>
</div>
<div class="" style="margin-bottom:176px;">

</div>
<div class="">
  <footer class="bg-secondary text-light text-center"> Copyright 2019 By Pratham InfoTech Foundation</footer>
</div>
</body>
</html>
