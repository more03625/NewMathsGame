<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Bungee+Inline|Cabin+Sketch&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="student_image/pratham.jpeg">
    <link href='https://fonts.googleapis.com/css?family=Metal Mania' rel='stylesheet'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
      <link href="https://fonts.googleapis.com/css?family=Permanent+Marker&display=swap" rel="stylesheet">
        <!-- <?php
         // session_start();
         ?> -->
      <style media="screen">

      .artical{background-image:url("image/DSC100399901.jpg");
        width:101vw;
      height:80vh;


    }

      body {
    font-family: 'Metal Mania';font-size: 22px;
}
      .form{
      background-color:rgba(255,0,255,0.4);
      margin-top:4vh;height:70vh;
    }


      .h{
        font-family: 'Metal Mania';font-size: 30px;   color: #00bacc;


      }
      #head{
        font-family: 'Metal Mania';font-size: 80px;

      }

      </style>
  </head>

  <body>
    <!-- <?php

   // if(!isset($_SESSION['admin_id'])){
   //   header('Location: ../index.php');
   }

   ?> -->

    <nav class="navbar navbar-light container-fluid sticky-top" style=" background: linear-gradient(to right, #ffffff 17%, #ffccff 100%);">

        <div class="col-lg-3 col-3">
          <a class="navbar-brand" href="../index.php">
            <img src="../Images/1520320708piflogo.png"  class="img-fluid mb-1" alt="">
          </a>
        </div>
        <div class="col-lg-3 col-6">
            <h1 class="align-bottom pl-4" style="font-size:5vw;font-family: 'Metal Mania', cursive;color:yellowgreen">Quiz<span style="font-family: 'Metal Mania', cursive;color:Blue;font-size:3vw;">Time</span></h1>
        </div>
        <!-- <div class="col-lg-2 col-3  justify-content-center" >
          <form class="form-colntrol" action="logout.php" method="post">
                   <!-- <?php 

                                    // error_reporting(0);
                                    // if (strlen($_SESSION['email'])==0) {
                                    //   echo "<a href='../index.php' class='btn btn-primary'>Logout</a>";
                                    // } else {
                                    //     echo "<input type='submit' class='btn btn-primary' style='margin-left:13vw;' name='logout' value='Logout'>";
                                    // }
                                     ?> -->

                                   <!-- </form> -->
        <!-- </div> -->

      <!-- </nav> -->








  </body>
</html>
