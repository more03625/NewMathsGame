<?php
$servername = "localhost";
$username = "pratiksha";
$password = "Pari@123";
$dbname = "SpellingMaker";

$conn =mysqli_connect($servername, $username, $password, $dbname)or die;
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
      $grade=$_POST['grad'];
      $level=$_POST['lev'];
      $question=$_POST['qname'];
      $name = $_FILES['file']['name'];
      $op1=$_POST['op1'];
      $op2=$_POST['op2'];
      $op3=$_POST['op3'];
      $op4=$_POST['op4'];
      $op5=$_POST['op5'];
      $op6=$_POST['op6'];
      $op7=$_POST['op7'];
      $cans=$_POST['ca'];
      $target_dir = "queimg/$lid";
      $target_file = $target_dir . basename($_FILES["file"]["name"]);

     // Insert record
     $query = "insert into question values(null,'$grade','$level','$question','".$name."','$op1','$op2','$op3','$op4','$op5','$op6','$op7','$cans')";
      if (mysqli_query($conn,$query)) {
        header('Location:questions.php?msg=Questions added succesfully...');
          move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
      }else {
        header('Location:questions.php?msg=question Not added succesfully...');
      }

?>
